"""replays - recording engine (v3: sound recorded by the app itself).

Why v3: the user's log showed the gyan.dev ffmpeg build has no WASAPI
capture device at all ("Unrecognized option 'loopback'", and no wasapi
in the device list), and the PC has no Stereo Mix device either - only
microphones. So ffmpeg cannot take the PC's output sound on that PC.

v3 therefore records sound in Python with the `soundcard` library
(WASAPI loopback of the default speaker), in 2-second WAV chunks next
to the video segments. On save, the WAV chunks are joined and muxed
into the MP4 with ffmpeg.

Video stays light: ddagrab first (Desktop Duplication, works on
integrated graphics), gdigrab fallback, ffmpeg at below-normal
priority so the game and network win.
Other OSes: a test pattern + sine tone is used (old path), so the
join/save logic can be tried anywhere.
"""
import os
import shutil
import subprocess
import sys
import threading
import time
import wave

try:
    import soundcard as sc
except Exception:  # not installed / not Windows
    sc = None

SEGMENT_SECONDS = 2
AUDIO_RATE = 48000
AUDIO_CHANNELS = 2


def find_ffmpeg():
    """ffmpeg next to the exe / bundled inside the exe / on PATH."""
    candidates = []
    if getattr(sys, "frozen", False):
        candidates.append(os.path.join(os.path.dirname(sys.executable), "ffmpeg.exe"))
        meipass = getattr(sys, "_MEIPASS", None)
        if meipass:
            # Single-exe build: ffmpeg.exe is packed inside and unpacked here.
            candidates.append(os.path.join(meipass, "ffmpeg.exe"))
    candidates.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "ffmpeg.exe"))
    candidates.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "ffmpeg"))
    found = shutil.which("ffmpeg")
    if found:
        candidates.append(found)
    for path in candidates:
        if path and os.path.exists(path):
            return path
    return None


def join_wavs(paths, out_path):
    """Join same-format WAV files into one. Returns True on success."""
    if not paths:
        return False
    try:
        with wave.open(paths[0], "rb") as first:
            params = first.getparams()
        with wave.open(out_path, "wb") as out:
            out.setparams(params)
            for path in paths:
                with wave.open(path, "rb") as src:
                    if src.getparams()[:3] != params[:3]:
                        continue
                    out.writeframes(src.readframes(src.getnframes()))
        return os.path.getsize(out_path) > 44
    except Exception:
        return False


class AudioChunkRecorder(threading.Thread):
    """Records the PC's output sound (WASAPI loopback) in 2s WAV chunks."""

    def __init__(self, buffer_dir, stop_event, on_error=None):
        super().__init__(daemon=True)
        self.buffer_dir = buffer_dir
        self.stop_event = stop_event
        self.on_error = on_error or (lambda msg: None)
        self.first_chunk = threading.Event()
        self.error = None

    def run(self):
        if sc is None:
            self.error = "soundcard library is not available"
            self.on_error(self.error)
            return
        try:
            speaker = sc.default_speaker()
            mic = sc.get_microphone(id=str(speaker.name), include_loopback=True)
            index = 0
            frames_per_chunk = AUDIO_RATE * SEGMENT_SECONDS
            with mic.recorder(samplerate=AUDIO_RATE, channels=AUDIO_CHANNELS) as rec:
                while not self.stop_event.is_set():
                    data = rec.record(numframes=frames_per_chunk)  # float32 [-1, 1]
                    pcm = (data * 32767).astype("int16")
                    path = os.path.join(self.buffer_dir, f"aud{index % 100000:05d}.wav")
                    with wave.open(path, "wb") as out:
                        out.setnchannels(AUDIO_CHANNELS)
                        out.setsampwidth(2)
                        out.setframerate(AUDIO_RATE)
                        out.writeframes(pcm.tobytes())
                    index += 1
                    self.first_chunk.set()
        except Exception as exc:  # keep the app alive, video still records
            self.error = f"{type(exc).__name__}: {exc}"
            self.on_error(self.error)


class ReplayEngine:
    def __init__(self, config, on_status=None):
        self.config = config
        self.on_status = on_status or (lambda msg: None)
        self.process = None
        self.buffer_dir = None
        self.audio_ok = False
        self.capture_mode = ""
        self._log_file = None
        self._stop_event = threading.Event()
        self._cleaner = None
        self._lock = threading.Lock()
        self._audio_recorder = None

    # ---------- helpers ----------
    def _status(self, msg):
        try:
            self.on_status(msg)
        except Exception:
            pass

    def _files(self, prefix, suffix):
        if not self.buffer_dir or not os.path.isdir(self.buffer_dir):
            return []
        files = []
        for name in os.listdir(self.buffer_dir):
            if name.startswith(prefix) and name.endswith(suffix):
                path = os.path.join(self.buffer_dir, name)
                try:
                    files.append((os.path.getmtime(path), path))
                except OSError:
                    pass
        files.sort()
        return [p for _, p in files]

    def _segment_files(self):
        return self._files("seg", ".mp4")

    def _audio_files(self):
        return self._files("aud", ".wav")

    # ---------- command building (video; ffmpeg audio only for the test OS path) ----------
    def _build_command(self, ffmpeg, video_kind, encoder, with_ffmpeg_audio):
        height = int(self.config["resolution"])
        fps = int(self.config["fps"])
        out_pattern = os.path.join(self.buffer_dir, "seg%05d.mp4")
        scale = f"scale=-2:{height}:flags=fast_bilinear"

        cmd = [ffmpeg, "-y", "-hide_banner", "-loglevel", "error"]
        enc = ["-c:v", "libx264", "-preset", "ultrafast", "-tune", "zerolatency", "-crf", "23"]
        if sys.platform == "win32":
            if video_kind == "ddagrab":
                cmd += ["-f", "lavfi", "-i", f"ddagrab=framerate={fps}"]
                if encoder == "qsv":  # Intel QuickSync (integrated graphics)
                    vf = f"hwdownload,format=nv12,{scale},format=nv12,hwupload=extra_hw_frames=64"
                    enc = ["-c:v", "h264_qsv", "-preset", "veryfast", "-global_quality", "23"]
                elif encoder == "amf":  # AMD integrated / Radeon
                    vf = f"hwdownload,format=nv12,{scale},format=yuv420p"
                    enc = ["-c:v", "h264_amf", "-usage", "ultralowlatency",
                           "-quality", "speed", "-rc", "cqp", "-qp_i", "23", "-qp_p", "23"]
                elif encoder == "nvenc":
                    vf = f"hwdownload,format=nv12,{scale},format=yuv420p"
                    enc = ["-c:v", "h264_nvenc", "-preset", "p1", "-tune", "ull", "-cq", "23"]
                else:
                    vf = f"hwdownload,format=bgra,{scale},format=yuv420p"
            else:
                cmd += ["-f", "gdigrab", "-framerate", str(fps), "-i", "desktop"]
                vf = f"{scale},format=yuv420p"
        else:
            cmd += ["-f", "lavfi", "-i", f"testsrc2=size=1280x720:rate={fps}"]
            vf = f"{scale},format=yuv420p"
            if with_ffmpeg_audio:
                cmd += ["-f", "lavfi", "-i", "sine=frequency=440:sample_rate=48000"]

        cmd += ["-vf", vf] + enc + ["-r", str(fps), "-g", str(fps * SEGMENT_SECONDS)]
        if with_ffmpeg_audio:
            cmd += ["-map", "0:v", "-map", "1:a",
                    "-c:a", "aac", "-b:a", "128k", "-ac", "2", "-ar", "48000"]
        cmd += ["-f", "segment", "-segment_time", str(SEGMENT_SECONDS),
                "-reset_timestamps", "1", out_pattern]
        return cmd

    # ---------- recording ----------
    def start(self):
        with self._lock:
            if self.process:
                return True
            ffmpeg = find_ffmpeg()
            if not ffmpeg:
                self._status("ffmpeg が見つかりません。ffmpeg.exe をこのアプリと同じフォルダに入れてください。")
                return False
            self.buffer_dir = os.path.join(os.path.expanduser("~"), ".nogpureplay_buffer")
            os.makedirs(self.buffer_dir, exist_ok=True)
            for old in self._segment_files() + self._audio_files():
                try:
                    os.remove(old)
                except OSError:
                    pass

            log_path = os.path.join(self.buffer_dir, "ffmpeg_log.txt")
            try:
                self._log_file = open(log_path, "w", encoding="utf-8", errors="replace")
            except OSError:
                self._log_file = None

            if sys.platform == "win32":
                # Lightest first: hardware encoding on integrated graphics,
                # then CPU encoding. A failed attempt just falls through.
                attempts = [("ddagrab", "qsv", False), ("ddagrab", "amf", False),
                            ("ddagrab", "nvenc", False), ("ddagrab", "x264", False),
                            ("gdigrab", "x264", False)]
            else:
                attempts = [("test", "x264", True), ("test", "x264", False)]

            flags = 0
            if sys.platform == "win32":
                flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) | 0x00004000

            started = False
            for video_kind, encoder, with_audio in attempts:
                cmd = self._build_command(ffmpeg, video_kind, encoder, with_audio)
                if self._log_file:
                    self._log_file.write(f"\n=== try video={video_kind} encoder={encoder} ===\n")
                    self._log_file.flush()
                try:
                    self.process = subprocess.Popen(
                        cmd, stdout=subprocess.DEVNULL,
                        stderr=self._log_file or subprocess.DEVNULL,
                        creationflags=flags)
                except Exception:
                    self.process = None
                    continue
                time.sleep(1.2)
                if self.process.poll() is None:
                    self.capture_mode = video_kind
                    self.encoder_used = encoder
                    self.audio_ok = bool(with_audio)  # test-OS path only
                    started = True
                    break
                self.process = None

            if not started:
                self._status("録画を始められませんでした。ffmpeg_log.txt を見てください。")
                return False

            self._stop_event.clear()

            # Sound: recorded by the app itself on Windows (v3).
            if sys.platform == "win32":
                self.audio_ok = False
                self._audio_recorder = AudioChunkRecorder(
                    self.buffer_dir, self._stop_event,
                    on_error=lambda msg: self._log_line(f"audio recorder: {msg}"))
                self._audio_recorder.start()
                if self._audio_recorder.first_chunk.wait(timeout=4):
                    self.audio_ok = True
                else:
                    self._log_line(f"audio recorder gave no chunk. error={self._audio_recorder.error}")

            self._cleaner = threading.Thread(target=self._cleanup_loop, daemon=True)
            self._cleaner.start()
            if self.capture_mode == "ddagrab" and getattr(self, "encoder_used", "x264") != "x264":
                light = "軽い取り方・ハードウェア処理"
            elif self.capture_mode == "ddagrab":
                light = "軽い取り方"
            else:
                light = "通常の取り方"
            if self.audio_ok:
                self._status(f"録画中です（{light}・音あり）。")
            else:
                self._status(f"録画中です（{light}・音は取れなかったので映像だけです）。")
            return True

    def _log_line(self, text):
        if self._log_file:
            try:
                self._log_file.write(text + "\n")
                self._log_file.flush()
            except Exception:
                pass

    def _cleanup_loop(self):
        while not self._stop_event.is_set():
            keep = int(self.config["duration"]) + 12
            now = time.time()
            for path in self._segment_files() + self._audio_files():
                try:
                    if now - os.path.getmtime(path) > keep:
                        os.remove(path)
                except OSError:
                    pass
            time.sleep(5)

    def stop(self):
        with self._lock:
            self._stop_event.set()
            if self.process:
                try:
                    self.process.terminate()
                    self.process.wait(timeout=5)
                except Exception:
                    try:
                        self.process.kill()
                    except Exception:
                        pass
                self.process = None
            self._audio_recorder = None
            if self._log_file:
                try:
                    self._log_file.close()
                except Exception:
                    pass
                self._log_file = None
            self._status("止めました。")

    @property
    def running(self):
        return self.process is not None and self.process.poll() is None

    # ---------- saving ----------
    def save_replay(self):
        """Join the last N seconds. Returns output path or None."""
        ffmpeg = find_ffmpeg()
        if not ffmpeg or not self.running:
            self._status("録画中じゃないので保存できません。")
            return None
        duration = int(self.config["duration"])
        files = self._segment_files()
        if len(files) < 2:
            self._status("まだ映像がたまっていません。少し待ってから押してください。")
            return None
        files = files[:-1]  # newest segment is still being written
        need = duration // SEGMENT_SECONDS + 1
        files = files[-need:]
        if not files:
            return None

        out_dir = os.path.expanduser(self.config["save_folder"])
        os.makedirs(out_dir, exist_ok=True)
        stamp = time.strftime("%Y%m%d-%H%M%S")
        out_path = os.path.join(out_dir, f"replay-{stamp}.mp4")
        temp_video = os.path.join(self.buffer_dir, "temp_video.mp4")

        list_path = os.path.join(self.buffer_dir, "concat.txt")
        with open(list_path, "w", encoding="utf-8") as f:
            for path in files:
                f.write("file '%s'\n" % path.replace("\\", "/").replace("'", "'\\''"))

        base = [ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
                "-f", "concat", "-safe", "0", "-i", list_path]
        made = False
        for extra in (["-c", "copy"], ["-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-c:a", "aac"]):
            try:
                result = subprocess.run(base + extra + [temp_video],
                                        capture_output=True, timeout=120,
                                        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            except Exception:
                continue
            if result.returncode == 0 and os.path.exists(temp_video) and os.path.getsize(temp_video) > 10000:
                made = True
                break
        if not made:
            self._status("保存に失敗しました。")
            return None

        # Sound chunks recorded by the app (Windows path): join + mux.
        aud_files = self._audio_files()
        if len(aud_files) >= 2:
            aud_files = aud_files[:-1][-need:]  # skip chunk being written
            joined_wav = os.path.join(self.buffer_dir, "joined.wav")
            if join_wavs(aud_files, joined_wav):
                try:
                    result = subprocess.run(
                        [ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
                         "-i", temp_video, "-i", joined_wav,
                         "-map", "0:v", "-map", "1:a",
                         "-c:v", "copy", "-c:a", "aac", "-b:a", "128k",
                         "-shortest", out_path],
                        capture_output=True, timeout=120,
                        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                except Exception:
                    result = None
                if result is not None and result.returncode == 0 and \
                        os.path.exists(out_path) and os.path.getsize(out_path) > 10000:
                    self._status(f"保存しました: {out_path}")
                    return out_path
                self._log_line("audio mux failed; saving video only.")

        # No separate sound chunks (or mux failed): the temp file is final.
        try:
            shutil.move(temp_video, out_path)
            self._status(f"保存しました: {out_path}")
            return out_path
        except Exception:
            self._status("保存に失敗しました。")
            return None

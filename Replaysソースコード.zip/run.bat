@echo off
chcp 65001 >nul
cd /d "%~dp0"
title replays
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_ffmpeg.ps1"
if errorlevel 1 goto FAILED
python -c "import soundcard, pystray, PIL" 2>nul
if errorlevel 1 python -m pip install soundcard pystray pillow
python main.py
goto END
:FAILED
echo ffmpeg no junbi ni shippai shimashita.
:END
pause

"""replays - instant replay without a graphics card.

Start it, play your game, press the hotkey, and the last 15-60 seconds
(with sound) are saved as an MP4 into the folder you chose.
"""
import ctypes
import json
import os
import sys
import threading
import tkinter as tk
import webbrowser
from tkinter import filedialog, ttk

APP_NAME = "replays"
GITHUB_URL = "https://github.com/trs00131"
GITHUB_USER = "trs00131"

from replay_engine import ReplayEngine

try:
    import pystray
    from PIL import Image
except Exception:  # tray is optional; the app still works without it
    pystray = None
    Image = None

APP_DIR = os.path.dirname(sys.executable) if getattr(sys, "frozen", False) \
    else os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(APP_DIR, "config.json")


def resource_path(name):
    """Files bundled into the exe (icon, chime), or next to the script."""
    base = getattr(sys, "_MEIPASS", APP_DIR)
    path = os.path.join(base, name)
    return path if os.path.exists(path) else os.path.join(APP_DIR, name)


DEFAULT_CONFIG = {
    "resolution": 720,        # 480 / 720 / 1080
    "fps": 30,                # 15 / 30 / 60
    "duration": 30,           # 15 / 30 / 45 / 60 (seconds)
    "save_folder": os.path.join(os.path.expanduser("~"), "Videos", "replays"),
    "hotkey": "F9",
    "audio_device": "virtual-audio-capturer",  # legacy, unused since v3
    "save_sound_mode": "system",   # system / chime / custom
    "save_sound_file": "",         # .wav path when mode is custom
}

SOUND_MODES = {"システム音": "system", "内蔵チャイム": "chime", "自分のファイル": "custom"}
SOUND_MODE_LABELS = {v: k for k, v in SOUND_MODES.items()}


def load_config():
    config = dict(DEFAULT_CONFIG)
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, encoding="utf-8") as f:
                config.update(json.load(f))
        except Exception:
            pass
    return config


def save_config(config):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=2)


def play_saved_sound(mode="system", sound_file=""):
    """Sound so the user knows the replay was saved. Mode is configurable."""
    if sys.platform == "win32":
        try:
            import winsound
            if mode == "chime":
                winsound.PlaySound(resource_path("saved_chime.wav"),
                                   winsound.SND_FILENAME | winsound.SND_ASYNC)
                return
            if mode == "custom" and sound_file and os.path.exists(sound_file):
                winsound.PlaySound(sound_file, winsound.SND_FILENAME | winsound.SND_ASYNC)
                return
            winsound.PlaySound("SystemAsterisk", winsound.SND_ALIAS | winsound.SND_ASYNC)
            return
        except Exception:
            pass
    print("\a", end="", flush=True)  # fallback bell


# ---------------- Windows global hotkey (RegisterHotKey) ----------------
MODIFIERS = {"ctrl": 0x0002, "alt": 0x0001, "shift": 0x0004, "win": 0x0008}


def parse_hotkey(text):
    """'Ctrl+Shift+F9' -> (modifiers, vk). Returns None if unknown."""
    parts = [p.strip().lower() for p in text.split("+") if p.strip()]
    if not parts:
        return None
    mods = 0
    for part in parts[:-1]:
        if part not in MODIFIERS:
            return None
        mods |= MODIFIERS[part]
    key = parts[-1].upper()
    if len(key) >= 2 and key[0] == "F" and key[1:].isdigit():
        num = int(key[1:])
        if 1 <= num <= 24:
            return mods, 0x70 + num - 1
        return None
    if len(key) == 1 and (key.isalpha() or key.isdigit()):
        return mods, ord(key)
    special = {"SPACE": 0x20, "HOME": 0x24, "END": 0x23,
               "INSERT": 0x2D, "DELETE": 0x2E, "PAUSE": 0x13}
    if key in special:
        return mods, special[key]
    return None


class HotkeyThread(threading.Thread):
    """Listens for the global hotkey on Windows. Does nothing elsewhere."""

    def __init__(self, hotkey_text, callback):
        super().__init__(daemon=True)
        self.hotkey_text = hotkey_text
        self.callback = callback
        self._stop = threading.Event()

    def stop(self):
        self._stop.set()
        if sys.platform == "win32":
            try:
                ctypes.windll.user32.PostThreadMessageW(
                    ctypes.c_ulong(self.ident or 0), 0x0012, 0, 0)  # WM_QUIT
            except Exception:
                pass

    def run(self):
        if sys.platform != "win32":
            return
        parsed = parse_hotkey(self.hotkey_text)
        if not parsed:
            return
        mods, vk = parsed
        user32 = ctypes.windll.user32
        if not user32.RegisterHotKey(None, 1, mods, vk):
            return
        try:
            import ctypes.wintypes as wintypes
            msg = wintypes.MSG()
            while not self._stop.is_set():
                if user32.GetMessageW(ctypes.byref(msg), None, 0, 0) <= 0:
                    break
                if msg.message == 0x0312:  # WM_HOTKEY
                    self.callback()
        finally:
            user32.UnregisterHotKey(None, 1)


# ---------------- GUI ----------------
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.resizable(False, False)
        try:
            self.iconbitmap(resource_path("icon.ico"))
        except Exception:
            pass
        self.config_data = load_config()
        self.engine = ReplayEngine(self.config_data, on_status=self._set_status_threadsafe)
        self.hotkey_thread = None
        self._capturing_key = False
        self.tray_icon = None
        self._build_ui()
        self._apply_config_to_ui()
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.after(400, self._auto_start)  # always recording while the app is open

    def _auto_start(self):
        if not self.engine.running:
            self._toggle_recording()
        self._setup_tray()
        if self.tray_icon is not None:
            # Live in the tray (notification area), not the taskbar.
            self.withdraw()
            try:
                self.tray_icon.notify("録画中です。アイコンから設定や保存ができます。",
                                      APP_NAME)
            except Exception:
                pass

    def _build_ui(self):
        pad = {"padx": 10, "pady": 4}
        frame = ttk.Frame(self)
        frame.pack(padx=12, pady=12)

        ttk.Label(frame, text="replays ― グラボなしでも使えるインスタントリプレイ",
                  font=("", 12, "bold")).grid(row=0, column=0, columnspan=3, pady=(0, 8))

        ttk.Label(frame, text="解像度").grid(row=1, column=0, sticky="e", **pad)
        self.res_var = tk.StringVar()
        ttk.Combobox(frame, textvariable=self.res_var, state="readonly", width=12,
                     values=["480p", "720p", "1080p"]).grid(row=1, column=1, sticky="w", **pad)

        ttk.Label(frame, text="フレームレート").grid(row=2, column=0, sticky="e", **pad)
        self.fps_var = tk.StringVar()
        ttk.Combobox(frame, textvariable=self.fps_var, state="readonly", width=12,
                     values=["15 fps", "30 fps", "60 fps"]).grid(row=2, column=1, sticky="w", **pad)

        ttk.Label(frame, text="保存する長さ").grid(row=3, column=0, sticky="e", **pad)
        self.dur_var = tk.StringVar()
        ttk.Combobox(frame, textvariable=self.dur_var, state="readonly", width=12,
                     values=["15秒", "30秒", "45秒", "60秒"]).grid(row=3, column=1, sticky="w", **pad)

        ttk.Label(frame, text="保存先フォルダ").grid(row=4, column=0, sticky="e", **pad)
        self.folder_var = tk.StringVar()
        ttk.Entry(frame, textvariable=self.folder_var, width=34).grid(row=4, column=1, sticky="w", **pad)
        ttk.Button(frame, text="選ぶ", command=self._choose_folder).grid(row=4, column=2, **pad)

        ttk.Label(frame, text="保存キー").grid(row=5, column=0, sticky="e", **pad)
        self.hotkey_var = tk.StringVar()
        ttk.Entry(frame, textvariable=self.hotkey_var, width=16).grid(row=5, column=1, sticky="w", **pad)
        ttk.Button(frame, text="キーを押して決める", command=self._start_key_capture).grid(row=5, column=2, **pad)

        ttk.Label(frame, text="保存したときの音").grid(row=6, column=0, sticky="e", **pad)
        self.sound_var = tk.StringVar()
        ttk.Combobox(frame, textvariable=self.sound_var, state="readonly", width=12,
                     values=list(SOUND_MODES.keys())).grid(row=6, column=1, sticky="w", **pad)
        sound_btns = ttk.Frame(frame)
        sound_btns.grid(row=6, column=2, sticky="w", **pad)
        ttk.Button(sound_btns, text="ファイルを選ぶ", command=self._choose_sound_file).pack(side="left")
        ttk.Button(sound_btns, text="試す", command=self._test_sound).pack(side="left", padx=4)
        self.sound_file_var = tk.StringVar()
        ttk.Entry(frame, textvariable=self.sound_file_var, width=34).grid(row=7, column=1, sticky="w", **pad)
        ttk.Label(frame, text="（自分のファイル用。.wav）", foreground="#888").grid(row=7, column=0, sticky="e", **pad)

        buttons = ttk.Frame(frame)
        buttons.grid(row=8, column=0, columnspan=3, pady=10)
        self.start_btn = ttk.Button(buttons, text="録画スタート", command=self._toggle_recording)
        self.start_btn.pack(side="left", padx=4)
        ttk.Button(buttons, text="今すぐ保存", command=self._save_replay).pack(side="left", padx=4)
        ttk.Button(buttons, text="設定を保存", command=self._save_settings).pack(side="left", padx=4)
        ttk.Button(buttons, text="保存先を開く", command=self._open_folder).pack(side="left", padx=4)

        self.status_var = tk.StringVar(value="起動しました。自動で録画を始めます…")
        ttk.Label(frame, textvariable=self.status_var, wraplength=430,
                  foreground="#444").grid(row=9, column=0, columnspan=3, pady=(2, 0))
        ttk.Label(frame, text="※ 設定は次に録画をスタートしたときから効きます。\n"
                              "※ 閉じるとトレイ（通知領域）に入ります。終わるときはトレイの「終了」から。",
                  foreground="#888").grid(row=10, column=0, columnspan=3)

        credit = ttk.Frame(frame)
        credit.grid(row=11, column=0, columnspan=3, pady=(8, 0))
        ttk.Label(credit, text="credit: GitHub ").pack(side="left")
        link = tk.Label(credit, text=GITHUB_USER, foreground="#2563eb",
                        font=("", 9, "underline"), cursor="hand2")
        link.pack(side="left")
        link.bind("<Button-1>", lambda event: webbrowser.open(GITHUB_URL))

    def _apply_config_to_ui(self):
        c = self.config_data
        self.res_var.set(f"{c['resolution']}p")
        self.fps_var.set(f"{c['fps']} fps")
        self.dur_var.set(f"{c['duration']}秒")
        self.folder_var.set(c["save_folder"])
        self.hotkey_var.set(c["hotkey"])
        self.sound_var.set(SOUND_MODE_LABELS.get(c.get("save_sound_mode", "system"), "システム音"))
        self.sound_file_var.set(c.get("save_sound_file", ""))

    def _read_ui_to_config(self):
        self.config_data["resolution"] = int(self.res_var.get().replace("p", ""))
        self.config_data["fps"] = int(self.fps_var.get().split()[0])
        self.config_data["duration"] = int(self.dur_var.get().replace("秒", ""))
        self.config_data["save_folder"] = self.folder_var.get().strip() or DEFAULT_CONFIG["save_folder"]
        self.config_data["hotkey"] = self.hotkey_var.get().strip() or "F9"
        self.config_data["save_sound_mode"] = SOUND_MODES.get(self.sound_var.get(), "system")
        self.config_data["save_sound_file"] = self.sound_file_var.get().strip()

    # ----- actions -----
    def _choose_folder(self):
        chosen = filedialog.askdirectory(initialdir=self.folder_var.get() or os.path.expanduser("~"))
        if chosen:
            self.folder_var.set(chosen)

    def _start_key_capture(self):
        self._capturing_key = True
        self.status_var.set("使いたいキーを押してください（例：F9、Ctrl+F9）。Escでやめます。")
        self.bind("<KeyPress>", self._on_key_capture)

    def _on_key_capture(self, event):
        if not self._capturing_key:
            return
        self._capturing_key = False
        self.unbind("<KeyPress>")
        if event.keysym == "Escape":
            self.status_var.set("キーの設定をやめました。")
            return
        parts = []
        state = event.state
        if state & 0x0004:
            parts.append("Ctrl")
        if state & 0x20000 or state & 0x0008:
            parts.append("Alt")
        if state & 0x0001:
            parts.append("Shift")
        key = event.keysym
        if key in ("Control_L", "Control_R", "Alt_L", "Alt_R", "Shift_L", "Shift_R"):
            self._capturing_key = True
            self.bind("<KeyPress>", self._on_key_capture)
            return
        parts.append(key.upper() if len(key) == 1 else key.capitalize())
        self.hotkey_var.set("+".join(parts))
        self.status_var.set(f"保存キーを {self.hotkey_var.get()} にしました。「設定を保存」を押してください。")

    def _toggle_recording(self):
        if self.engine.running:
            self.engine.stop()
            self._stop_hotkey()
            self.start_btn.config(text="録画スタート")
        else:
            self._read_ui_to_config()
            save_config(self.config_data)
            if self.engine.start():
                self.start_btn.config(text="止める")
                self._start_hotkey()

    def _start_hotkey(self):
        self._stop_hotkey()
        self.hotkey_thread = HotkeyThread(self.config_data["hotkey"],
                                          lambda: self.after(0, self._save_replay))
        self.hotkey_thread.start()

    def _stop_hotkey(self):
        if self.hotkey_thread:
            self.hotkey_thread.stop()
            self.hotkey_thread = None

    def _save_replay(self):
        mode = self.config_data.get("save_sound_mode", "system")
        sound_file = self.config_data.get("save_sound_file", "")

        def job():
            path = self.engine.save_replay()
            if path:
                play_saved_sound(mode, sound_file)
        threading.Thread(target=job, daemon=True).start()

    def _choose_sound_file(self):
        chosen = filedialog.askopenfilename(
            title="保存したときの音（.wav）",
            filetypes=[("WAV", "*.wav"), ("すべてのファイル", "*.*")])
        if chosen:
            self.sound_file_var.set(chosen)
            self.sound_var.set("自分のファイル")

    def _test_sound(self):
        self._read_ui_to_config()
        play_saved_sound(self.config_data["save_sound_mode"],
                         self.config_data["save_sound_file"])

    # ----- tray (notification area) -----
    def _setup_tray(self):
        if pystray is None or Image is None or sys.platform != "win32":
            return
        try:
            image = Image.open(resource_path("icon.ico"))
        except Exception:
            return
        menu = pystray.Menu(
            pystray.MenuItem("設定を開く", lambda icon, item: self.after(0, self._show_window),
                             default=True),
            pystray.MenuItem("今すぐ保存", lambda icon, item: self.after(0, self._save_replay)),
            pystray.MenuItem("終了", lambda icon, item: self.after(0, self._quit_app)),
        )
        self.tray_icon = pystray.Icon(APP_NAME, image, APP_NAME, menu)
        try:
            self.tray_icon.run_detached()
        except Exception:
            self.tray_icon = None

    def _show_window(self):
        self.deiconify()
        self.lift()
        self.focus_force()

    def _quit_app(self):
        self.engine.stop()
        self._stop_hotkey()
        if self.tray_icon is not None:
            try:
                self.tray_icon.stop()
            except Exception:
                pass
            self.tray_icon = None
        self.destroy()

    def _save_settings(self):
        self._read_ui_to_config()
        save_config(self.config_data)
        if parse_hotkey(self.config_data["hotkey"]) is None and sys.platform == "win32":
            self.status_var.set("そのキーは使えません。F9 や Ctrl+F9 の形で書いてください。")
            return
        self.status_var.set("設定を保存しました。次に録画をスタートしたときから効きます。")
        if self.engine.running:
            self._start_hotkey()  # hotkey change applies right away

    def _open_folder(self):
        folder = os.path.expanduser(self.folder_var.get())
        os.makedirs(folder, exist_ok=True)
        if sys.platform == "win32":
            os.startfile(folder)  # noqa: S606
        else:
            import subprocess
            subprocess.Popen(["xdg-open", folder])

    def _set_status_threadsafe(self, msg):
        self.after(0, lambda: self.status_var.set(msg))

    def _on_close(self):
        # Closing the window puts the app in the tray; it keeps recording.
        if self.tray_icon is not None:
            self.withdraw()
        else:
            self._quit_app()


if __name__ == "__main__":
    App().mainloop()

@echo off
chcp 65001 >nul
cd /d "%~dp0"
title replays Build
set LOG=%~dp0build_log.txt
echo replays build log > "%LOG%"
echo.
echo [1/3] ffmpeg wo kakunin shimasu...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_ffmpeg.ps1" >> "%LOG%" 2>&1
if errorlevel 1 goto FAILED_FFMPEG
echo [2/3] PyInstaller to buhin wo iremasu (shokai dake)...
python -m pip install pyinstaller soundcard pystray pillow >> "%LOG%" 2>&1
if errorlevel 1 goto FAILED_PIP
echo [3/3] exe wo tsukurimasu (shibaraku kakakarimasu)...
python -m PyInstaller --onefile --windowed --name replays --icon icon.ico --add-data "icon.ico;." --add-data "saved_chime.wav;." --add-data "ffmpeg.exe;." --collect-all soundcard --collect-all pystray main.py >> "%LOG%" 2>&1
if errorlevel 1 goto FAILED_BUILD
if exist "%~dp0ffmpeg.exe" copy /y "%~dp0ffmpeg.exe" "%~dp0dist\ffmpeg.exe" >nul
echo.
echo Dekimashita: dist\replays.exe
echo replays.exe dake de ugokimasu (ffmpeg wa naka ni haitte imasu).
goto END
:FAILED_FFMPEG
echo.
echo Shippai: ffmpeg no junbi. build_log.txt wo mite kudasai.
goto END
:FAILED_PIP
echo.
echo Shippai: install. build_log.txt wo mite kudasai.
goto END
:FAILED_BUILD
echo.
echo Shippai: exe no sakusei. build_log.txt wo mite kudasai.
:END
echo.
pause

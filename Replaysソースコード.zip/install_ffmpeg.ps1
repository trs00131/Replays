# replays - ffmpeg check & install
# 1. ffmpeg.exe next to this script -> OK
# 2. ffmpeg on PATH -> copy it next to this script, OK
# 3. Not found -> download the release build and put ffmpeg.exe here
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"  # no progress numbers, and much faster
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$target = Join-Path $here "ffmpeg.exe"

if (Test-Path $target) {
    Write-Host "ffmpeg: already here (ffmpeg.exe)."
    exit 0
}

$found = Get-Command ffmpeg -ErrorAction SilentlyContinue
if ($found) {
    Write-Host "ffmpeg: found on this PC. Copying it here..."
    Copy-Item $found.Source $target -Force
    Write-Host "ffmpeg: ready."
    exit 0
}

Write-Host "ffmpeg: not found. Downloading..."
$url = "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"
$tmp = Join-Path $env:TEMP ("nogpu_ffmpeg_" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $tmp | Out-Null
try {
    $zip = Join-Path $tmp "ffmpeg.zip"
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing
    Expand-Archive -Path $zip -DestinationPath $tmp -Force
    $exe = Get-ChildItem -Path $tmp -Recurse -Filter "ffmpeg.exe" | Select-Object -First 1
    if (-not $exe) { throw "ffmpeg.exe was not in the downloaded file." }
    Copy-Item $exe.FullName $target -Force
    Write-Host "ffmpeg: installed."
} catch {
    Write-Host "ffmpeg: download failed. $($_.Exception.Message)"
    Write-Host "Please put ffmpeg.exe in this folder yourself: $here"
    exit 1
} finally {
    Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
}
exit 0
